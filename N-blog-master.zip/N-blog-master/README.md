N-blog
======

使用 Express + MongoDB 搭建多人博客  

教程见 [wiki](https://github.com/nswbmw/N-blog/wiki/_pages)


### 分支说明

- master: express4.x 版，受限于排版原因尽量做了最少的改动从原来的express3.x升到express4.x
- express4.x: express4.x 版，代码进行了重构
- koa: koa 版
- master-express3.x-backup: express3.x 版，备份